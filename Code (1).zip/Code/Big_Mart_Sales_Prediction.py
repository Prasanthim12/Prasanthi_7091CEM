import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn import metrics
from xgboost import XGBRegressor
from sklearn.linear_model import LinearRegression,Ridge,Lasso
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

bigMart_sales_data = pd.read_csv("Train.csv")
print(bigMart_sales_data.head())
print(bigMart_sales_data.describe())
bigMart_sales_data.info()

print(bigMart_sales_data.isnull().sum())

plt.figure(figsize=(6,6))
axis = plt.gca()
axis.set_title("Quality Vs Item Weight")
sns.distplot(bigMart_sales_data['Item_Weight'])
#plt.show()


plt.figure(figsize=(6,6))
sns.distplot(bigMart_sales_data['Item_Visibility'])
#plt.show()

plt.figure(figsize=(6,6))
sns.countplot(x='Outlet_Establishment_Year', data = bigMart_sales_data)
#plt.show()

plt.figure(figsize=(6,6))
sns.countplot(x='Item_Fat_Content', data = bigMart_sales_data)
#plt.show()

plt.figure(figsize=(30,6))
sns.countplot(x='Item_Type', data = bigMart_sales_data)
#plt.show()

plt.figure(figsize=(6,6))
sns.countplot(x='Outlet_Size', data = bigMart_sales_data)
#plt.show()

#Finding the missing values
print("________________________________________________________________________________")
print("Finding and Filling the missing values")
print("________________________________________________________________________________")
print(bigMart_sales_data.isnull().sum())

#Filling the missing values for Item Fat Content
bigMart_sales_data.replace({'Item_Fat_Content': {'low fat' : 'Low Fat', 'LF': 'Low Fat', 'reg': 'Regular'}},inplace=True)

#Finding and Filling the missing values for Item Weight
item_weight_mean = bigMart_sales_data.pivot_table(values="Item_Weight",index="Item_Identifier" )
miss_Item_Weight = bigMart_sales_data['Item_Weight'].isnull()
for i,item in enumerate(bigMart_sales_data['Item_Identifier']):
    if miss_Item_Weight[i]:
        if item in item_weight_mean:
            bigMart_sales_data['Item_Weight'][i] = item_weight_mean.loc[item]['Item_Weight']
        else:
            bigMart_sales_data['Item_Weight'][i] = np.mean(bigMart_sales_data['Item_Weight'])

#Finding the missing values in Outlet Size
outlet = bigMart_sales_data.pivot_table(values='Outlet_Size',columns='Outlet_Type', aggfunc=(lambda x: x.mode()[0]))
miss_Outlet_Size = bigMart_sales_data['Outlet_Size'].isnull()

#Filling the missing values in Outlet Size
bigMart_sales_data.loc[miss_Outlet_Size,'Outlet_Size'] = bigMart_sales_data.loc[miss_Outlet_Size,'Outlet_Type'].apply(lambda x:outlet[x])

#Final Output after finding and filling the missing values

print("________________________________________________________________________________")
print("Final Output after finding and filling the missing values")
print("________________________________________________________________________________")
print(bigMart_sales_data.isnull().sum())

correlation = bigMart_sales_data.corr()
sns.heatmap(correlation, annot = True, cmap="Reds")
#plt.show()


#Label Encoding
#from sklearn.preprocessing import LabelEncoder
label_Encoder = LabelEncoder()
bigMart_sales_data['Item_Identifier'] = label_Encoder.fit_transform(bigMart_sales_data['Item_Identifier'])
bigMart_sales_data['Item_Fat_Content'] = label_Encoder.fit_transform(bigMart_sales_data['Item_Fat_Content'])
bigMart_sales_data['Item_Type'] = label_Encoder.fit_transform(bigMart_sales_data['Item_Type'])
bigMart_sales_data['Outlet_Identifier'] = label_Encoder.fit_transform(bigMart_sales_data['Outlet_Identifier'])
bigMart_sales_data['Outlet_Size'] = label_Encoder.fit_transform(bigMart_sales_data['Outlet_Size'])
bigMart_sales_data['Outlet_Location_Type'] = label_Encoder.fit_transform(bigMart_sales_data['Outlet_Location_Type'])
bigMart_sales_data['Outlet_Type'] = label_Encoder.fit_transform(bigMart_sales_data['Outlet_Type'])



#Removing Unwanted Attributes
print("________________________________________________________________________________")
print("After Removing Unwanted Attributes")
print("________________________________________________________________________________")
X = bigMart_sales_data.drop(columns=['Outlet_Establishment_Year','Item_Identifier','Outlet_Identifier','Item_Outlet_Sales'])
X.info()


Y = bigMart_sales_data['Item_Outlet_Sales']


#Split the Train & Test Data
X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2, random_state=2)
X.shape
Y.shape
X_train.shape
X_test.shape
Y_train.shape
Y_test.shape

xgbRegressor = XGBRegressor()
xgbRegressor.fit(X_train,Y_train)
train_prediction = xgbRegressor.predict(X_train)

rSquared_train = metrics.r2_score(Y_train, train_prediction)
print(rSquared_train)

test_prediction = xgbRegressor.predict(X_test)
rSquared_test = metrics.r2_score(Y_test, test_prediction)
print(rSquared_test)



def train1(model,X,Y):
    model.fit(X,Y)
    prediction = model.predict(X)
    cross_value_score = cross_val_score(model,X,Y,scoring= 'neg_mean_squared_error',cv = 5)
    cross_value_score = np.abs(np.mean(cross_value_score))
    print("The Mean Squared Error Value is ")
    print(mean_squared_error(Y,prediction))
    print("The Cross Value Score is ")
    print(cross_value_score)


print("________________________________________________________________________________")
print("Linear Regression")
print("________________________________________________________________________________")

model = LinearRegression()
t = train1(model,X,Y)
coef = pd.Series(model.coef_,X.columns).sort_values()
coef.plot(kind='bar')
#plt.show()


print("________________________________________________________________________________")
print("Ridge")
print("________________________________________________________________________________")
model = Ridge()
t = train1(model,X,Y)
coef = pd.Series(model.coef_,X.columns).sort_values()
coef.plot(kind='bar')
#plt.show()



print("________________________________________________________________________________")
print("Random Forest Regressor")
print("________________________________________________________________________________")
model = RandomForestRegressor()
t = train1(model,X,Y)
coef = pd.Series(model.feature_importances_,X.columns).sort_values()
coef.plot(kind='bar',title="Random Forest Regressor")
#plt.show()



print("________________________________________________________________________________")
print("Decision Tree Regressor")
print("________________________________________________________________________________")
model = DecisionTreeRegressor()
t = train1(model,X,Y)
coef = pd.Series(model.feature_importances_,X.columns).sort_values()
coef.plot(kind='bar')
#plt.show()